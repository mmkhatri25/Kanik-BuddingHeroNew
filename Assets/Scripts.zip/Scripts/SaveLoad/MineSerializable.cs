using System;

namespace SaveLoad
{
	[Serializable]
	public class MineSerializable
	{
		public bool unlocked;

		public int level;

		public long time;
	}
}
