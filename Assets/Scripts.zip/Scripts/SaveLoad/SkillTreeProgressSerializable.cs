using System;

namespace SaveLoad
{
	[Serializable]
	public class SkillTreeProgressSerializable
	{
		public int ulti;

		public int[][] branches;
	}
}
