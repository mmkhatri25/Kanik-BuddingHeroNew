using System;

namespace SaveLoad
{
	[Serializable]
	public class CharmLevelStatusSerializable
	{
		public int lvl;

		public int usdupe;
	}
}
