using System;

namespace SaveLoad
{
	[Serializable]
	public class SpecialOfferKeeperSeralizable
	{
		public long nextOfferApperTime;

		public long offerEndTime;

		public int offerPack;
	}
}
