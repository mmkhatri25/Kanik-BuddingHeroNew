using System;

public class IapIds
{
	public static int GEM_PACK_01;

	public static int GEM_PACK_02 = 1;

	public static int GEM_PACK_03 = 2;

	public static int GEM_PACK_04 = 3;

	public static int GEM_PACK_05 = 4;

	public static int GEM_PACK_06 = 5;

	public static int STARTER_PACK = 6;

	public static int CURRENCY_PACK = 7;

	public static int XMAS_PACK = 8;

	public static int MID_GEM_OFFER = 9;

	public static int MID_GEM_OFFER_TWO = 10;

	public static int RIFT_OFFER_01 = 11;

	public static int RIFT_OFFER_02 = 12;

	public static int RIFT_OFFER_03 = 13;

	public static int REGIONAL_01 = 14;

	public static int STAGE_100_OFFER = 15;

	public static int RIFT_OFFER_04 = 16;

	public static int HALLOWEEN_GEMS_PACK = 17;

	public static int CANDY_PACK_01 = 18;

	public static int CANDY_PACK_02 = 19;

	public static int CHRISTMAS_GEMS_SMALL_PACK = 20;

	public static int CHRISTMAS_GEMS_BIG_PACK = 21;

	public static int STAGE_300_OFFER = 22;

	public static int STAGE_800_OFFER = 23;

	public static int SECOND_ANNIVERSARY_GEMS = 24;

	public static int SECOND_ANNIVERSARY_CURRENCY_PACK = 25;

	public static int SECOND_ANNIVERSARY_GEMS_TWO = 26;

	public static int SECOND_ANNIVERSARY_CURRENCY_PACK_TWO = 27;
}
