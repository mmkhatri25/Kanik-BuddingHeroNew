using System;

public static class HeroSkinIndexes
{
	public const int HORATIO_default = 0;

	public const int HORATIO_skin_1 = 1;

	public const int HORATIO_skin_2 = 2;

	public const int HORATIO_skin_3 = 3;

	public const int HORATIO_skin_4 = 4;

	public const int HORATIO_skin_5 = 5;

	public const int HORATIO_skin_6 = 6;

	public const int HORATIO_skin_7 = 7;

	public const int HORATIO_skin_10_viking = 8;

	public const int HORATIO_skin_11 = 9;

	public const int HORATIO_skin_8_pijama = 10;

	public const int HORATIO_skin_9_skeleton = 11;

	public const int THOUR_default = 0;

	public const int THOUR_skin_1 = 1;

	public const int THOUR_skin_2 = 2;

	public const int THOUR_skin_3 = 3;

	public const int THOUR_skin_4 = 4;

	public const int THOUR_skin_5 = 5;

	public const int THOUR_skin_6 = 6;

	public const int THOUR_skin_7 = 7;

	public const int THOUR_skin_8_pijama = 8;

	public const int THOUR_skin_9_diver = 9;

	public const int THOUR_skin_10_robot = 10;

	public const int THOUR_skin_11_frankenstein = 11;

	public const int IDA_default = 0;

	public const int IDA_skin_1 = 1;

	public const int IDA_skin_2 = 2;

	public const int IDA_skin_3 = 3;

	public const int IDA_skin_4 = 4;

	public const int IDA_skin_5 = 5;

	public const int IDA_skin_6 = 6;

	public const int IDA_skin_7 = 7;

	public const int IDA_skin_11 = 8;

	public const int IDA_skin_10_thor = 9;

	public const int IDA_skin_8_pijama = 10;

	public const int IDA_skin_9_rosie = 11;

	public const int KIND_LENNY_default = 0;

	public const int KIND_LENNY_skin_1 = 1;

	public const int KIND_LENNY_skin_2 = 2;

	public const int KIND_LENNY_skin_3 = 3;

	public const int KIND_LENNY_skin_4 = 4;

	public const int KIND_LENNY_skin_5 = 5;

	public const int KIND_LENNY_skin_6 = 6;

	public const int KIND_LENNY_skin_7 = 7;

	public const int KIND_LENNY_skin_13 = 8;

	public const int KIND_LENNY_skin_10_steampunk = 9;

	public const int KIND_LENNY_skin_11_referal = 10;

	public const int KIND_LENNY_skin_12_zombie = 11;

	public const int KIND_LENNY_skin_8_pijama = 12;

	public const int KIND_LENNY_skin_9_arctic = 13;

	public const int DEREK_default = 0;

	public const int DEREK_skin_1 = 1;

	public const int DEREK_skin_2 = 2;

	public const int DEREK_skin_3 = 3;

	public const int DEREK_skin_4 = 4;

	public const int DEREK_skin_5 = 5;

	public const int DEREK_skin_6 = 6;

	public const int DEREK_skin_7 = 7;

	public const int DEREK_skin_8_pijama = 8;

	public const int DEREK_skin_9_biker = 9;

	public const int DEREK_skin_10_gentleman = 10;

	public const int DEREK_skin_11_fisherman = 11;

	public const int SHEELA_default = 0;

	public const int SHEELA_skin_1 = 1;

	public const int SHEELA_skin_2 = 2;

	public const int SHEELA_skin_3 = 3;

	public const int SHEELA_skin_4 = 4;

	public const int SHEELA_skin_5 = 5;

	public const int SHEELA_skin_6 = 6;

	public const int SHEELA_skin_7 = 7;

	public const int SHEELA_skin_11 = 8;

	public const int SHEELA_skin_10_little_principe = 9;

	public const int SHEELA_skin_8_pijama = 10;

	public const int SHEELA_skin_9_ninja = 11;

	public const int BOMBERMAN_default = 0;

	public const int BOMBERMAN_skin_1 = 1;

	public const int BOMBERMAN_skin_2 = 2;

	public const int BOMBERMAN_skin_3 = 3;

	public const int BOMBERMAN_skin_4 = 4;

	public const int BOMBERMAN_skin_5 = 5;

	public const int BOMBERMAN_skin_6 = 6;

	public const int BOMBERMAN_skin_7 = 7;

	public const int BOMBERMAN_skin_8_pijama = 8;

	public const int BOMBERMAN_skin_9_gasmask = 9;

	public const int BOMBERMAN_skin_10_scientist = 10;

	public const int BOMBERMAN_skin_pirate = 11;

	public const int SAM_default = 0;

	public const int SAM_skin_1 = 1;

	public const int SAM_skin_2 = 2;

	public const int SAM_skin_3 = 3;

	public const int SAM_skin_4 = 4;

	public const int SAM_skin_5 = 5;

	public const int SAM_skin_6 = 6;

	public const int SAM_skin_7 = 7;

	public const int SAM_skin_8_pijama = 8;

	public const int SAM_skin_9_jail = 9;

	public const int SAM_skin_10security = 10;

	public const int SAM_skin_11_gnome = 11;

	public const int BLIND_ARCHER_default = 0;

	public const int BLIND_ARCHER_skin_1 = 1;

	public const int BLIND_ARCHER_skin_2 = 2;

	public const int BLIND_ARCHER_skin_3 = 3;

	public const int BLIND_ARCHER_skin_4 = 4;

	public const int BLIND_ARCHER_skin_5 = 5;

	public const int BLIND_ARCHER_skin_6 = 6;

	public const int BLIND_ARCHER_skin_7 = 7;

	public const int BLIND_ARCHER_skin_8_pijama = 8;

	public const int BLIND_ARCHER_skin_9_postapocalyptic = 9;

	public const int BLIND_ARCHER_skin_10_samurai = 10;

	public const int BLIND_ARCHER_skin_11_mummy = 11;

	public const int JIM_default = 0;

	public const int JIM_skin_01 = 1;

	public const int JIM_skin_02 = 2;

	public const int JIM_skin_03 = 3;

	public const int JIM_skin_04 = 4;

	public const int JIM_skin_05 = 5;

	public const int JIM_skin_06 = 6;

	public const int JIM_skin_07 = 7;

	public const int JIM_skin_08_pijama = 8;

	public const int JIM_skin_09_gnome = 9;

	public const int JIM_skin_10_guitarist = 10;

	public const int JIM_skin_11_jazz = 11;

	public const int TAM_default = 0;

	public const int TAM_skin_1 = 1;

	public const int TAM_skin_2 = 2;

	public const int TAM_skin_3 = 3;

	public const int TAM_skin_4 = 4;

	public const int TAM_skin_5 = 5;

	public const int TAM_skin_6 = 6;

	public const int TAM_skin_7 = 7;

	public const int TAM_skin_8_pijama = 8;

	public const int TAM_skin_9_pirate = 9;

	public const int TAM_skin_10_cowboy = 10;

	public const int TAM_skin_11_clown = 11;

	public const int WARLOCK_default = 0;

	public const int WARLOCK_skin_1 = 1;

	public const int WARLOCK_skin_2 = 2;

	public const int WARLOCK_skin_3 = 3;

	public const int WARLOCK_skin_4 = 4;

	public const int WARLOCK_skin_5 = 5;

	public const int WARLOCK_skin_6 = 6;

	public const int WARLOCK_skin_7 = 7;

	public const int WARLOCK_skin_11 = 8;

	public const int WARLOCK_skin_10_luchador = 9;

	public const int WARLOCK_skin_8_pijama = 10;

	public const int WARLOCK_skin_9_vampire = 11;

	public const int GOBLIN_default = 0;

	public const int GOBLIN_skin_1 = 1;

	public const int GOBLIN_skin_2 = 2;

	public const int GOBLIN_skin_3 = 3;

	public const int GOBLIN_skin_4 = 4;

	public const int GOBLIN_skin_5 = 5;

	public const int GOBLIN_skin_6 = 6;

	public const int GOBLIN_skin_7 = 7;

	public const int GOBLIN_skin_11_birthday = 8;

	public const int GOBLIN_skin_10_tourist = 9;

	public const int GOBLIN_skin_8_pijama = 10;

	public const int GOBLIN_skin_9_leprechaun = 11;

	public const int BABU_default = 0;

	public const int BABU_skin_1 = 1;

	public const int BABU_skin_2 = 2;

	public const int BABU_skin_3 = 3;

	public const int BABU_skin_4 = 4;

	public const int BABU_skin_5 = 5;

	public const int BABU_skin_6 = 6;

	public const int BABU_skin_7 = 7;

	public const int BABU_skin_8 = 8;

	public const int BABU_skin_9 = 9;

	public const int BABU_skin_10 = 10;

	public const int BABU_skin_11 = 11;

	public const int DRUID_default = 0;

	public const int DRUID_skin_01 = 1;

	public const int DRUID_skin_02 = 2;

	public const int DRUID_skin_03 = 3;

	public const int DRUID_skin_04 = 4;

	public const int DRUID_skin_05 = 5;

	public const int DRUID_skin_06 = 6;

	public const int DRUID_skin_07 = 7;

	public const int DRUID_skin_08_pijama = 8;

	public const int DRUID_skin_09_plant = 9;

	public const int DRUID_skin_10_snow = 10;

	public const int DRUID_skin_11_sheep = 11;

	public const int DRUID_skin_u01 = 12;

	public const int DRUID_skin_u02 = 13;

	public const int DRUID_skin_u03 = 14;

	public const int DRUID_skin_u04 = 15;

	public const int DRUID_skin_u05 = 16;

	public const int DRUID_skin_u06 = 17;

	public const int DRUID_skin_u07 = 18;

	public const int DRUID_skin_u08_pijama = 19;

	public const int DRUID_skin_u09_plant = 20;

	public const int DRUID_skin_u10_snow = 21;

	public const int DRUID_skin_u11_sheep = 22;
}
