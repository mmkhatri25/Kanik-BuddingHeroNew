using System;

public interface IProvideWeight
{
	float GetWeight();
}
