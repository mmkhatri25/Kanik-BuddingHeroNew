using System;
using UnityEngine;
using UnityEngine.UI;

public class TextContainer : MonoBehaviour
{
	public Text text;

	public Canvas canvas;
}
