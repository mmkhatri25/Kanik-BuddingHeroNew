using System;
using UnityEngine;

public class FPSDisplay : MonoBehaviour
{
	public Main main;
}
