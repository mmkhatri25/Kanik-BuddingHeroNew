using System;

namespace UIReborn
{
	internal interface ILoclized
	{
		void InitStrings();
	}
}
