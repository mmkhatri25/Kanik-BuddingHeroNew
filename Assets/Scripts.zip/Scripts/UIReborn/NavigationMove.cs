using System;

namespace UIReborn
{
	public class NavigationMove
	{
		public UIWindowBase previousWindow;

		public UIWindowBase nextWindow;
	}
}
