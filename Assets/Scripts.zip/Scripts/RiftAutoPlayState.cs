using System;

public enum RiftAutoPlayState
{
	NONE,
	START,
	PLAYING,
	END
}
