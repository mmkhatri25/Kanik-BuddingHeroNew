using System;

public enum SoundType
{
	GAMEPLAY,
	UI,
	AMBIENT,
	MUSIC,
	MUSIC_BOSS
}
