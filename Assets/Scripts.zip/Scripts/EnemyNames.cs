using System;

public static class EnemyNames
{
	public const string BANDIT = "BANDIT";

	public const string WOLF = "WOLF";

	public const string SPIDER = "SPIDER";

	public const string BAT = "BAT";

	public const string ELF_SEMI_CORRUPTED = "SEMI CORRUPTED ELF";

	public const string ELF_CORRUPTED = "CORRUPTED ELF";

	public const string DWARF_SEMI_CORRUPTED = "SEMI CORRUPTED DWARF";

	public const string DWARF_CORRUPTED = "CORRUPTED DWARF";

	public const string HUMAN_CORRUPTED = "CORRUPTED HUMAN";

	public const string HUMAN_SEMI_CORRUPTED = "SEMI CORRUPTED HUMAN";

	public const string MANGOLIES = "MANGOLIES";

	public const string CHEST = "CHEST";

	public const string BOSS = "BOSS";

	public const string BOSS_ELF = "BOSS ELF";

	public const string BOSS_DWARF = "BOSS DWARF";

	public const string BOSS_HUMAN = "BOSS HUMAN";

	public const string BOSS_MANGOLIES = "BOSS MANGOLIES";

	public const string BOSS_WISE_SNAKE = "BOSS WISE SNAKE";

	public const string SNAKE = "SNAKE";

	public const string BOSS_SNOWMAN = "BOSS SNOWMAN";
}
