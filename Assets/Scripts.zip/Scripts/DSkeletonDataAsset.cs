using System;
using Spine.Unity;

[Serializable]
public class DSkeletonDataAsset : DynamicLoadObject<SkeletonDataAsset>
{
}
