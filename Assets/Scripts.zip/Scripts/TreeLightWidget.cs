using System;
using UnityEngine;
using UnityEngine.UI;

public class TreeLightWidget : MonoBehaviour
{
	public Image baseImage;

	public Image glowImage;
}
