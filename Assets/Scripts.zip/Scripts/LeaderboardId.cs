using System;

public static class LeaderboardId
{
	public static string MAX_STAGE = "CgkIlpSuuo0ZEAIQQg";
}
