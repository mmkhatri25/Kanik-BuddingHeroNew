using System;

public interface IMatchRemovable
{
	bool willDispose { get; set; }
}
