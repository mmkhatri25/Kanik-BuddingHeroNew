using System;

namespace Ui
{
	public class TextData : AahMonoBehaviour
	{
		public bool resizeTextForBestFit;
	}
}
