using System;

namespace Ui
{
	public delegate void CommandAction();
}
