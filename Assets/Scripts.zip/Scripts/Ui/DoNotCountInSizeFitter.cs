using System;

namespace Ui
{
	public class DoNotCountInSizeFitter : AahMonoBehaviour
	{
	}
}
