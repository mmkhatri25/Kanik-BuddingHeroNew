using System;
using UnityEngine;
using UnityEngine.UI;

namespace Ui
{
	public class UniversalBonusUnitWidget : MonoBehaviour
	{
		public Image icon;

		public Text textBonus;
	}
}
