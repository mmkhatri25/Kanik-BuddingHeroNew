using System;
using UnityEngine.UI;

namespace Ui
{
	public class BossFrame : AahMonoBehaviour
	{
		public Image boss;
	}
}
