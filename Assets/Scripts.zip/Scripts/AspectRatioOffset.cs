using System;

public class AspectRatioOffset
{
	public static float HERO_X;

	public static float ENEMY_X;
}
