using System;

namespace Ui
{
	public struct MultiJumpResult
	{
		public int jumpCount;

		public double amountToConsume;
	}
}
