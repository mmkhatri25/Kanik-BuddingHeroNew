using System;
using UnityEngine;

[Serializable]
public class DGameObject : DynamicLoadObject<GameObject>
{
}
