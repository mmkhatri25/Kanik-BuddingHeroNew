using System;

public enum Language
{
	EN,
	TR,
	ES,
	IT,
	FR,
	DE,
	PT,
	RU,
	ZH,
	JP,
	KR
}
